<?php $__env->startSection('body'); ?>

<!-- Begin Input Pegawai  -->
<div class="kt-container  kt-grid__item kt-grid__item--fluid">
    <div class="row">
        <div class="col-lg-12">
            <div class="kt-portlet">
        <div class="kt-portlet__head">
            <div class="kt-portlet__head-label">
                <h3 class="kt-portlet__head-title">
                    Input Pegawai
                </h3>
            </div>
        </div>
        <!--begin::Form-->
    <form class="kt-form kt-form--label-right" action="<?php echo e(route('master.store')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="kt-portlet__body">

                <div class="form-group row"></div>
                <div class="form-group row">
                    <div class="col-lg-6">
                        <label>NIP / NRP</label>
                        <input type="text" name="nip_nrp" value="<?php echo e(old('nip_nrp')); ?>" class="form-control <?php if ($errors->has('nip_nrp')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nip_nrp'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Masukkan NIP/NRP" required>
                        <?php if ($errors->has('nip_nrp')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nip_nrp'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="col-lg-6">
                        <label class="">Nama Pegawai</label>
                        <input type="text" name="nama_pegawai" value="<?php echo e(old('nama_pegawai')); ?>" class="form-control <?php if ($errors->has('nama_pegawai')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_pegawai'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Masukkan Nama Lengkap" required>
                        <?php if ($errors->has('nama_pegawai')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_pegawai'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-lg-6">
                        <label class="">Jenis Pegawai</label>
                        <select class="form-control <?php if ($errors->has('jenis_pegawai')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('jenis_pegawai'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('jenis_pegawai')); ?>" name="jenis_pegawai" required>
                            <option></option>
                            <option value="Polri" <?php if(old('jenis_pegawai') == "Polri"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Polri</option>
                            <option value="PNS" <?php if(old('jenis_pegawai') == "PNS"): ?> <?php echo e('selected'); ?> <?php endif; ?> >PNS</option>
                            <option value="Dosen Eksternal" <?php if(old('jenis_pegawai') == "Dosen Eksternal"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Dosen Eksternal</option>
                        </select>
                        <?php if ($errors->has('jenis_pegawai')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('jenis_pegawai'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                    </div>
                    <div class="col-lg-6">
                        <label class="">NIDN</label>
                        <input type="text" name="nidn" class="form-control <?php if ($errors->has('nidn')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nidn'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('nidn')); ?>" placeholder="Masukkan NIDN" required>
                        <?php if ($errors->has('nidn')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nidn'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-lg-6">
                        <label class="">No KTA Pegawai</label>
                        <input type="text"  name="no_kta_pegawai" class="form-control <?php if ($errors->has('no_kta_pegawai')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('no_kta_pegawai'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('no_kta_pegawai')); ?>" placeholder="Masukkan No KTA Pegawai" required>
                        <?php if ($errors->has('no_kta_pegawai')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('no_kta_pegawai'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="col-lg-6">
                        <label class="">No.Kep.Jabatan</label>
                        <input type="text" name="no_kep_jabatan" class="form-control <?php if ($errors->has('no_kep_jabatan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('no_kep_jabatan'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('no_kep_jabatan')); ?>" placeholder="Masukkan No.Kep.Jabatan" required>
                       <?php if ($errors->has('no_kep_jabatan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('no_kep_jabatan'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-lg-6">
                        <label class="">Pangkat</label>
                        <select class="form-control" name="pangkat" id="pangkat" required>
                            <option value="">pilih</option>
                            <?php $__currentLoopData = $pangkat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($pang->id); ?>" <?php echo e((old("pangkat") == $pang->id ? "selected":"")); ?>><?php echo e($pang->nama_pangkat); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if ($errors->has('pangkat')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pangkat'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="col-lg-6">
                        <label class="">Jabatan</label>
                        <select class="form-control" name="jabatan" id="jabatan" required>
                            <option value="">pilih</option>
                            <?php $__currentLoopData = $jabatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jabat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($jabat->id); ?>" <?php echo e((old("jabatan") == $jabat->id ? "selected":"")); ?>><?php echo e($jabat->nama_jabatan); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if ($errors->has('Pangkat')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Pangkat'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>
                <div class="form-group row">
                        <div class="col-lg-4">
                            <label class="">Kompartemen</label>
                            
                            <select class="form-control" name="id_kompartemen" id="kompartemen" required>
                                <option value="">pilih</option>
                                <?php $__currentLoopData = $kompartemen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <option value="<?php echo e($u->id); ?>" <?php echo e((old("id_kompartemen") == $u->id ? "selected":"")); ?>><?php echo e($u->nama_kompartemen); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-lg-4">
                                <label class="">Satker</label>
                                <select class="form-control" name="id_satker" id="satker" required>
                                </select>
                        </div>
                        <div class="col-lg-4">
                                <label class="">Divisi/Unit Kerja</label>
                                
                                <select class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="id_divisi" id="divisi" required>
                                </select>
                                <?php if ($errors->has('id_divisi')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('id_divisi'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                </div>

                <div class="form-group row"></div>
                <div class="form-group row">
                        <div class="col-lg-6">
                            <label class="">E-mail</label>
                            <input type="email" name="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('email')); ?>" placeholder="Masukkan Email" required>
                            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                </div>
                <div class="form-group row">
                        <div class="col-lg-6">
                            <label class="">Password</label>
                            <input type="password" name="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('password')); ?>" placeholder="Masukkan Password" required>
                            <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                        <div class="col-lg-6">
                            <label class="">Retype Password</label>
                            <input type="password" name="re_password" class="form-control <?php if ($errors->has('re_password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('re_password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('re_password')); ?>" placeholder="Masukkan Password Kembali" required>
                            <?php if ($errors->has('re_password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('re_password'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                </div>
                <div class="form-group row"></div>
                <div class="form-group row">
                        <label class="">Alamat</label>
                        <textarea name="alamat" class="form-control <?php if ($errors->has('alamat')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('alamat'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('alamat')); ?>" placeholder="Masukkan Alamat " required> <?php echo e(old('alamat')); ?></textarea>
                       <?php if ($errors->has('alamat')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('alamat'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="form-group row">
                    <div class="col-lg-6">
                        <label class="">Tempat Lahir</label>
                        <input type="text" name="tempat_lahir" class="form-control <?php if ($errors->has('tempat_lahir')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('tempat_lahir'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('tempat_lahir')); ?>" placeholder="Masukkan Tempat Lahir" required>
                       <?php if ($errors->has('tempat_lahir')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('tempat_lahir'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="col-lg-6">
                        <label class="">Tanggal Lahir</label>
                        <input type="date" name="tanggal_lahir" class="form-control <?php if ($errors->has('tanggal_lahir')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('tanggal_lahir'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('tanggal_lahir')); ?>" placeholder="Masukkan Tanggal Lahir" required>
                       <?php if ($errors->has('tanggal_lahir')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('tanggal_lahir'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-lg-6">
                        <label class="">Jenis Kelamin</label>
                        <select class="form-control <?php if ($errors->has('jk')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('jk'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('jk')); ?>" name="jk" id="sel1" required>
                            <option value="">pilih</option>
                            <option value="L"  <?php if(old('jk') == "L"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Laki-Laki</option>
                            <option value="P"   <?php if(old('jk') == "P"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Perempuan</option>
                        </select>
                        <?php if ($errors->has('jk')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('jk'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="col-lg-6">
                        <label class="">Agama</label>
                        <select class="form-control <?php if ($errors->has('agama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('agama'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('agama')); ?>" name="agama" required>
                                <option value="">pilih</option>
                                <option value="Islam" <?php if(old('agama') == "Islam"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Islam</option>
                                <option value="Kristen" <?php if(old('agama') == "Kristen"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Kristen</option>
                                <option value="Katolik" <?php if(old('agama') == "Katolik"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Katolik</option>
                                <option value="Hindu" <?php if(old('agama') == "Hindu"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Hindu</option>
                                <option value="Budha" <?php if(old('agama') == "Budha"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Budha</option>
                                <option value="Konghucu" <?php if(old('agama') == "Konghucu"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Konghucu</option>
                        </select>
                       <?php if ($errors->has('agama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('agama'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>
                <div class="form-group row"></div>

                <div class="form-group row">
                    <div class="col-lg-6">
                        <label class="">NIK</label>
                        <input type="text" name="nik" class="form-control <?php if ($errors->has('nik')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nik'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('nik')); ?>" placeholder="Masukkan NIK" required>
                       <?php if ($errors->has('nik')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nik'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>

                </div>
                <div class="form-group row"></div>
                <div class="form-group row">
                        <div class="col-lg-6">
                            <label class="">No HP</label>
                            <input type="text" name="no_hp" class="form-control <?php if ($errors->has('no_hp')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('no_hp'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('no_hp')); ?>" placeholder="Masukkan Nomer Handphone" required>
                                <?php if ($errors->has('no_hp')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('no_hp'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                        <div class="col-lg-6">
                            <label class="">Tanggal Masuk</label>
                            <input type="date" name="tgl_masuk" class="form-control <?php if ($errors->has('tgl_masuk')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('tgl_masuk'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('tgl_masuk')); ?>" placeholder="Tanggal Masuk" required>
                            <?php if ($errors->has('tgl_masuk')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('tgl_masuk'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                </div>
                <div class="form-group row">

                </div>
                <div class="form-group row"></div>
                
                    <label><b>Foto</b></label>
                    <div class="form-group row">
                        <input type="file" name="foto" class="form-control <?php if ($errors->has('foto')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('foto'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('foto')); ?>" col-lg-6" placeholder="Upload Foto" required>
                        <?php if ($errors->has('foto')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('foto'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
            </div>
            <div class="kt-portlet__foot">
                <div class="kt-form__actions">
                    <div class="row">
                        
                        <div class="col-lg-8">
                            <button type="submit" class="btn btn-primary">Submit</button>
                            
                        </div>
                    </div>
                </div>
            </div>

    </form>
        <!--end::Form-->
    </div>
    </div>
</div>
</div>
<!-- End form input -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('asset-buttom'); ?>
<script>
     $(document).ready(function(){
              $.ajaxSetup({
                  headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                  }
              });
})
$('#kompartemen').change(function(){
            var divisi=$(this).val();
            $.ajax({
                type:'post',
                url:'<?php echo e(route('kompartemen.satker')); ?>',
                data:{id:divisi,_token:'<?php echo e(csrf_token()); ?>'},
                success:function(data){
                    $('#satker').html(data);
                    console.log(data);
                }
            })
})
$('#satker').change(function(){
            var divisi=$(this).val();
            $.ajax({
                type:'post',
                url:'<?php echo e(route('satker.divisi')); ?>',
                data:{id:divisi,_token:'<?php echo e(csrf_token()); ?>'},
                success:function(data){
                    $('#divisi').html(data);
                    console.log(data);
                }
            })
})
var error='<?php echo old('id_divisi')?>';
var id='<?php echo old('id_kompartemen')?>';
if(error){
        $.ajax({
            type:'post',
            url:'<?php echo e(route('kompartemen.satker')); ?>',
            data:{id:id,id_selected:error,_token:'<?php echo e(csrf_token()); ?>'},
            success:function(data){
                $('#divisi').html(data);
                console.log(data);
            }
        })

}
var error='<?php echo old('id_kompartemen')?>';
var id='<?php echo old('id_satker')?>';
if(error){
        $.ajax({
            type:'post',
            url:'<?php echo e(route('satker.divisi')); ?>',
            data:{id:id,id_selected:error,_token:'<?php echo e(csrf_token()); ?>'},
            success:function(data){
                $('#satker').html(data);
                console.log(data);
            }
        })

}
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make("layouts.admin.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\72\Downloads\aaa-master\aaa-master\resources\views/master/create.blade.php ENDPATH**/ ?>