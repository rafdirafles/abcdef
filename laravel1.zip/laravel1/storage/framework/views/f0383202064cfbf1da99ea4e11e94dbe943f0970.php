<!DOCTYPE html>
<html>
<head>
	<title>Membuat Laporan PDF Dengan DOMPDF Laravel</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<style>
    .p_umum{
        margin-left: 20px;
    }
    .p{
        font-weight: bold
    }
    .ttd{
        float: right
    }
    .tengah{
        margin-top:50px;
    }
    .hidden{
        height: 20px;
    }
</style>
<?php
    date_default_timezone_set('Asia/Jakarta');
?>
<?php if(auth::user()->jenis_pegawai =="PNS" || auth::user()->jenis_pegawai =="Dosen Eksternal"): ?>
<center>
    <h5>DAFTAR RIWAYAT HIDUP</h4>
</center>
<table>
        <tr>
            <th>Data Pribadi</th>
            <td></td>
        </tr>
        <tr>
            <td>Nama</td>
            <td>:</td>
            <td><?php echo e($user->nama_pegawai); ?></td>
        </tr>
        <tr>
          <td>Jenis_kelamin</td>
          <td>:</td>
            <td><?php if($user->jk =='P'): ?>
                Perempuan
                <?php elseif($user->jk =='L'): ?>
                Laki-lakir
                 <?php endif; ?>

            </td>
        </tr>
        <tr>
          <td>Tempat Tanggal Lahir</td>
          <td>:</td>
          <td><?php echo e($user->tempat_lahir.','.$user->tanggal_lahir); ?></td>
        </tr>
        <tr>
                <td>Status Perkawinan</td>
                <td>:</td>
                <td>
                    <?php if(!empty($biodata)): ?>
                    <?php echo e($biodata->status_menikah); ?>

                    <?php endif; ?></td>
        </tr>
        <tr>
                <td>Agama</td>
                <td>:</td>
                <td><?php echo e($user->agama); ?></td>
        </tr>
        <tr>
                <td>Alamat</td>
                <td>:</td>
                <td><?php echo e($user->alamat); ?></td>
        </tr>
        <tr>
                <td>No Handphone</td>
                <td>:</td>
                <td><?php echo e($user->no_hp); ?></td>
        </tr>
        <tr>
                <td>Email</td>
                <td>:</td>
                <td><?php echo e($user->email); ?></td>
        </tr>
      </table>
      
      <p class="p" >DATA PENDIDIKAN</p>
      <table class="p_umum">
        <tr>
                <th>1.Pendidikan Umum</th>
                <td></td>
        </tr>
          <?php for($x=0;$x<count($p_umum);$x++): ?>
            <?php
                    $alpha=['a','b','c'.'d','e','f','g'];
            ?>
          <tr>
                <td><?php echo e($alpha[$x].'. tahun '.$p_umum[$x]['tahun_lulus']); ?></td>
                <td>:</td>
                <td><?php echo e($p_umum[$x]['nama_sekolah']); ?></td>
          </tr>

          <?php endfor; ?>
      </table>
      
      <table class="p_umum">
        <tr>
                <th>2.Pendidikan Non Formal</th>
                <td></td>
        </tr>
          <?php for($x=0;$x<count($p_non_formal);$x++): ?>
            <?php
                    $alpha=['a','b','c'.'d','e','f','g'];
            ?>
          <tr>
                <td><?php echo e($alpha[$x].'. tahun '.$p_non_formal[$x]['tahun_pendidikan']); ?></td>
                <td>:</td>
                <td><?php echo e($p_non_formal[$x]['nama_pendidikan']); ?></td>
          </tr>

          <?php endfor; ?>
      </table>
      <table class="p_umum">
        <tr>
                <th>3.Pendidikan Kejuruan</th>
                <td></td>
        </tr>
          <?php for($x=0;$x<count($p_kejuruan);$x++): ?>
            <?php
                    $alpha=['a','b','c'.'d','e','f','g'];
            ?>
          <tr>
                <td><?php echo e($alpha[$x].'. tahun '.$p_kejuruan[$x]['tahun_pendidikan']); ?></td>
                <td>:</td>
                <td><?php echo e($p_kejuruan[$x]['nama_pendidikan']); ?></td>
          </tr>

          <?php endfor; ?>
      </table>
      <p class="p" >BAHASA</p>
      <table class="p_umum">
        <tr>
                <th>1.Daerah</th>
                <td></td>
        </tr>
        <?php for($x=0;$x<count($bahasa);$x++): ?>
        <?php if($bahasa[$x]['jenis_bahasa'] =="Daerah"): ?>

            <?php
                    $alpha=['a','b','c'.'d','e','f','g'];
            ?>
            <tr>
                    <td><?php echo e($bahasa[$x]['nama_bahasa']); ?></td>
            </tr>
            <?php endif; ?>
        <?php endfor; ?>
      </table>
      <table class="p_umum">
        <tr>
                <th>1.Asing</th>
                <td></td>
        </tr>
        <?php for($x=0;$x<count($bahasa);$x++): ?>
        <?php if($bahasa[$x]['jenis_bahasa'] == "Asing"): ?>
            <?php
                    $alpha=['a','b','c'.'d','e','f','g'];
            ?>
            <tr>
                    <td><?php echo e($bahasa[$x]['nama_bahasa']); ?></td>
            </tr>
            <?php endif; ?>
        <?php endfor; ?>
      </table>
      <p class="p" >TANDA JASA</p>
      <table class="p_umum">
        <tr>
                <th></th>
                <td></td>
        </tr>
          <?php for($x=0;$x<count($tanda_jasa);$x++): ?>
            <?php
                    $alpha=['a','b','c'.'d','e','f','g'];
            ?>
          <tr>
                <td><?php echo e($alpha[$x].'. tahun '.$tanda_jasa[$x]['tahun']); ?></td>
                <td>:</td>
                <td><?php echo e($tanda_jasa[$x]['nama_prestasi']); ?></td>
          </tr>

          <?php endfor; ?>
      </table>
        <p class="p" >Riwayat</p>
        <table class="p_umum">
          <tr>
                  <th>1.Riwayat Kepangkatan</th>
                  <td></td>
          </tr>
          <?php

          ?>
          <?php $__currentLoopData = $r_pangkat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php
                      $alpha=['a','b','c'.'d','e','f','g'];
                      $i=0;
              ?>
            <tr>
                  <td><?php echo e('* tahun '.$p->tmt); ?></td>
                  <td>:</td>
                  <td><?php echo e($p->Pangkat->nama_pangkat); ?></td>
            </tr>
            <?php
                $i++;
            ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <table class="p_umum">
                <tr>
                        <th>2.Riwayat Jabatan</th>
                        <td></td>
                </tr>
                <?php
                ?>
                <?php $__currentLoopData = $r_jabatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jabatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                            $alpha=['a','b','c'.'d','e','f','g'];
                            $i=0;
                    ?>
                  <tr>
                        <td><?php echo e('* tahun '.$jabatan->tgl_mulai_terhitung); ?></td>
                        <td>:</td>
                        <td><?php echo e($jabatan->Jabatan->nama_jabatan); ?></td>
                  </tr>
                  <?php
                      $i++;
                  ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <br>
    <br>
    <br>
    <table class="ttd">
        <tr>
            <td>semarang,</td>
            <td><?php echo e(date("Y/m/d")); ?></td>
        </tr>
        <tr>
            <td class="tengah" colspan="2"><center>Yang Membuat</center></td>
        </tr>
        <tr>
            <td class="hidden"  colspan="2"></td>
        </tr>
        <tr>
            <td class="hidden"   colspan="2"></td>
        </tr>
        <tr>
            <td colspan="2"><center><?php echo e(auth::user()->nama_pegawai); ?></center></td>
        </tr>
        <tr>
        <td colspan="2"><center><?php echo e(auth::user()->Pangkat->nama_pangkat); ?> NIP <?php echo e(auth::user()->nip_nrp); ?></center></td>
        </tr>
    </table>

<?php else: ?>
<body>
	<center>
		<h5>DAFTAR RIWAYAT HIDUP</h4>
	</center>
    <table>
            <tr>
                <th>Data Pribadi</th>
                <td></td>
            </tr>
            <tr>
                <td>Nama</td>
                <td>:</td>
                <td><?php echo e($user->nama_pegawai); ?></td>
            </tr>
            <tr>
              <td>Jenis_kelamin</td>
              <td>:</td>
                <td><?php if($user->jk =='P'): ?>
                    Perempuan
                    <?php elseif($user->jk =='L'): ?>
                    Laki-lakir
                     <?php endif; ?>

                </td>
            </tr>
            <tr>
              <td>Tempat Tanggal Lahir</td>
              <td>:</td>
              <td><?php echo e($user->tempat_lahir.','.$user->tanggal_lahir); ?></td>
            </tr>
            <tr>
                    <td>Status Perkawinan</td>
                    <td>:</td>
                    <td>
                        <?php if(!empty($biodata)): ?>
                        <?php echo e($biodata->status_menikah); ?>

                        <?php endif; ?></td>
            </tr>
            <tr>
                    <td>Agama</td>
                    <td>:</td>
                    <td><?php echo e($user->agama); ?></td>
            </tr>
            <tr>
                    <td>Alamat</td>
                    <td>:</td>
                    <td><?php echo e($user->alamat); ?></td>
            </tr>
            <tr>
                    <td>No Handphone</td>
                    <td>:</td>
                    <td><?php echo e($user->no_hp); ?></td>
            </tr>
            <tr>
                    <td>Email</td>
                    <td>:</td>
                    <td><?php echo e($user->email); ?></td>
            </tr>
          </table>
          
          <p class="p" >DATA PENDIDIKAN</p>
          <table class="p_umum">
            <tr>
                    <th>1.Pendidikan Umum</th>
                    <td></td>
            </tr>
              <?php for($x=0;$x<count($p_umum);$x++): ?>
                <?php
                        $alpha=['a','b','c'.'d','e','f','g'];
                ?>
              <tr>
                    <td><?php echo e($alpha[$x].'. tahun '.$p_umum[$x]['tahun_lulus']); ?></td>
                    <td>:</td>
                    <td><?php echo e($p_umum[$x]['nama_sekolah']); ?></td>
              </tr>

              <?php endfor; ?>
          </table>
          
          <table class="p_umum">
            <tr>
                    <th>2.Pendidikan Non Formal</th>
                    <td></td>
            </tr>
              <?php for($x=0;$x<count($p_non_formal);$x++): ?>
                <?php
                        $alpha=['a','b','c'.'d','e','f','g'];
                ?>
              <tr>
                    <td><?php echo e($alpha[$x].'. tahun '.$p_non_formal[$x]['tahun_pendidikan']); ?></td>
                    <td>:</td>
                    <td><?php echo e($p_non_formal[$x]['nama_pendidikan']); ?></td>
              </tr>

              <?php endfor; ?>
          </table>
          <table class="p_umum">
            <tr>
                    <th>3.Pendidikan Kejuruan</th>
                    <td></td>
            </tr>
              <?php for($x=0;$x<count($p_kejuruan);$x++): ?>
                <?php
                        $alpha=['a','b','c'.'d','e','f','g'];
                ?>
              <tr>
                    <td><?php echo e($alpha[$x].'. tahun '.$p_kejuruan[$x]['tahun_pendidikan']); ?></td>
                    <td>:</td>
                    <td><?php echo e($p_kejuruan[$x]['nama_pendidikan']); ?></td>
              </tr>

              <?php endfor; ?>
          </table>
          <table class="p_umum">
            <tr>
                    <th>4.Pendidikan Polri</th>
                    <td></td>
            </tr>
              <?php for($x=0;$x<count($p_polri);$x++): ?>
                <?php
                        $alpha=['a','b','c'.'d','e','f','g'];
                ?>
              <tr>
                    <td><?php echo e($alpha[$x].'. tahun '.$p_polri[$x]['tahun']); ?></td>
                    <td>:</td>
                    <td><?php echo e($p_polri[$x]['nama_pendidikan']); ?></td>
              </tr>

              <?php endfor; ?>
          </table>
          <p class="p" >BAHASA</p>
          <table class="p_umum">
            <tr>
                    <th>1.Daerah</th>
                    <td></td>
            </tr>
            <?php for($x=0;$x<count($bahasa);$x++): ?>
            <?php if($bahasa[$x]['jenis_bahasa'] =="Daerah"): ?>

                <?php
                        $alpha=['a','b','c'.'d','e','f','g'];
                ?>
                <tr>
                        <td><?php echo e($bahasa[$x]['nama_bahasa']); ?></td>
                </tr>
                <?php endif; ?>
            <?php endfor; ?>
          </table>
          <table class="p_umum">
            <tr>
                    <th>1.Asing</th>
                    <td></td>
            </tr>
            <?php for($x=0;$x<count($bahasa);$x++): ?>
            <?php if($bahasa[$x]['jenis_bahasa'] == "Asing"): ?>
                <?php
                        $alpha=['a','b','c'.'d','e','f','g'];
                ?>
                <tr>
                        <td><?php echo e($bahasa[$x]['nama_bahasa']); ?></td>
                </tr>
                <?php endif; ?>
            <?php endfor; ?>
          </table>
          <p class="p" >TANDA JASA</p>
          <table class="p_umum">
            <tr>
                    <th></th>
                    <td></td>
            </tr>
              <?php for($x=0;$x<count($tanda_jasa);$x++): ?>
                <?php
                        $alpha=['a','b','c'.'d','e','f','g'];
                ?>
              <tr>
                    <td><?php echo e($alpha[$x].'. tahun '.$tanda_jasa[$x]['tahun']); ?></td>
                    <td>:</td>
                    <td><?php echo e($tanda_jasa[$x]['nama_prestasi']); ?></td>
              </tr>

              <?php endfor; ?>
          </table>
            <p class="p" >Riwayat</p>
            <table class="p_umum">
              <tr>
                      <th>1.Riwayat Kepangkatan</th>
                      <td></td>
              </tr>
              <?php

              ?>
              <?php $__currentLoopData = $r_pangkat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php
                          $alpha=['a','b','c'.'d','e','f','g'];
                          $i=0;
                  ?>
                <tr>
                      <td><?php echo e('* tahun '.$p->tmt); ?></td>
                      <td>:</td>
                      <td><?php echo e($p->Pangkat->nama_pangkat); ?></td>
                </tr>
                <?php
                    $i++;
                ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <table class="p_umum">
                    <tr>
                            <th>2.Riwayat Jabatan</th>
                            <td></td>
                    </tr>
                    <?php
                    ?>
                    <?php $__currentLoopData = $r_jabatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jabatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                                $alpha=['a','b','c'.'d','e','f','g'];
                                $i=0;
                        ?>
                      <tr>
                            <td><?php echo e('* tahun '.$jabatan->tgl_mulai_terhitung); ?></td>
                            <td>:</td>
                            <td><?php echo e($jabatan->Jabatan->nama_jabatan); ?></td>
                      </tr>
                      <?php
                          $i++;
                      ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <br>
        <br>
        <br>
        <table class="ttd">
            <tr>
                <td>semarang,</td>
                <td><?php echo e(date("Y/m/d")); ?></td>
            </tr>
            <tr>
                <td class="tengah" colspan="2"><center>Yang Membuat</center></td>
            </tr>
            <tr>
                <td class="hidden"  colspan="2"></td>
            </tr>
            <tr>
                <td class="hidden"   colspan="2"></td>
            </tr>
            <tr>
                <td colspan="2"><center><?php echo e(auth::user()->nama_pegawai); ?></center></td>
            </tr>
            <tr>
            <td colspan="2"><center><?php echo e(auth::user()->Pangkat->nama_pangkat); ?> NRP <?php echo e(auth::user()->nip_nrp); ?></center></td>
            </tr>
        </table>
</body>

<?php endif; ?>
</html>
<?php /**PATH C:\Users\72\Downloads\aaa-master\aaa-master\resources\views/Profile/cetak_rh.blade.php ENDPATH**/ ?>