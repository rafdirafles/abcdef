<!DOCTYPE html>
<html>
<head>
    <title>Pemberitahuan Cuti</title>
     <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Akademi Kepolisian</div>
                <div class="panel-body">
                        <p>Selamat Cuti anda sudah di ACC oleh Admin</p>
                        <p>Tanggal Mulai:<?php echo e($tgl_mulai); ?></p>
                        <p>Tanggal Mulai:<?php echo e($tgl_selesai); ?></p>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\Users\72\Downloads\aaa-master\aaa-master\resources\views/Pengajuan/send_email/index.blade.php ENDPATH**/ ?>