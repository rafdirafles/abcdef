<!DOCTYPE html>
<html>
<head>
    <title>Pemberitahuan Cuti</title>
     <link href="{{ asset('css/app.css') }}" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Akademi Kepolisian</div>
                <div class="panel-body">
                        <p>Maaf Pengajuan Cuti Anda Ditolak Oleh Admin Silahkan Input Lagi Dengan Benar</p>
                        <p>Tanggal Mulai:{{$tgl_mulai}}</p>
                        <p>Tanggal Mulai:{{$tgl_selesai}}</p>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
