<img src="{{asset('img/'.$user->foto)}}" alt="">
