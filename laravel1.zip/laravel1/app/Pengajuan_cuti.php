<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pengajuan_cuti extends Model
{
    //
}
