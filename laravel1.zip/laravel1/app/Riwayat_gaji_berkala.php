<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Riwayat_gaji_berkala extends Model
{
    //
    protected $fillable=['nip_nrp','gaji','tmt','nomor_sk','pejabat','tanggal_sk','dasar_peraturan'];
}
