<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tanda_jasa_Prestasi extends Model
{
    //
    protected $fillable=['nip_nrp','nama_prestasi','tahun','keterangan'];
}
