<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kecakapan_bahasa extends Model
{
    //
    protected $fillable=[ 'nip_nrp','jenis_bahasa','nama_bahasa','kemampuan_bahasa',];
}
