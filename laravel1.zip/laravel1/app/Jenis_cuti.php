<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Jenis_cuti extends Model
{
    //
    protected $fillable=['nama_cuti','lama_cuti'];
}
