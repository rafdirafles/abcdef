<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mutasi_masuk extends Model
{
    //
}
