<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pendidikan_polri extends Model
{
    //
    protected $fillable=['nip_nrp','nama_pendidikan','tahun','lulus_tidak','lama_bulan','rangking','file',];
}
