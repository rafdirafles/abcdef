<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kecakapan_olahraga_dan_beladiri extends Model
{
    //
    protected $fillable=['nip_nrp','nama_olahraga','keterangan'];
}
