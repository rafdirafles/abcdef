<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kompartemen extends Model
{
    //
    // protected $table='kompartemens';
    protected $fillable=['id','nama_kompartemen'];
}
