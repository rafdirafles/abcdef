<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class biodata extends Model
{
    //
    protected $fillable=['nip_nrp','status_menikah','no_kk','hobi','no_tlp','tinggi_badan','berat_badan','warna_rambut','bentuk_muka','warna_kulit','ciri_khas','cacat_tubuh'];
}
