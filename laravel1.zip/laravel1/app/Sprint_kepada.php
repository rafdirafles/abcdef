<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sprint_kepada extends Model
{
    //
}
