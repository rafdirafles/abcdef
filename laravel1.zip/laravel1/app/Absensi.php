<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Absensi extends Model
{
    //
    protected $fillable=['nip_nrp','status_absensi','tgl_absensi','keterangan'];
}
